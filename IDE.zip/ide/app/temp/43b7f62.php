<?php
echo 'Hello, World!'; 
?>