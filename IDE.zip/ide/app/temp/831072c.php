<?php 
echo 'Hello, World!';
?>